# VERSIONS
## v3.0.0 data intended for testing `nifti_clib` version 3.0.0

# nifti-test-data

A repository for storing test data used for the nifti project.  This repository is used as a storage location for the `nifti_clib` project initial conversion to github, and may be replaced with a more sustainable/modular solution in the future.

Releases of this data set will provide a link to a tarball that
can be used inside of the `nifti_clib` project for testing
the functionality of those programs.


## Data copied from [CiftiLib](https://github.com/Washington-University/CiftiLib/tree/master/example/data)

The Washington-University data is a convenience copy in the local diredtory.
